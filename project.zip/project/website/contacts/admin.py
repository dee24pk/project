from django.contrib import admin
from .models import contact_detail

class contact_detail_admin(admin.ModelAdmin):
	list_display = ["id", "name", "email", "phone_no", "updated", "timestamp"]
	list_display_links = ["name"]
	# list_editable = ["name", "email", "phone_no"]
	list_filter = ["updated", "timestamp"]
	search_fields = ["name", "email", "phone_no"]

	class meta:
		model = contact_detail

admin.site.register(contact_detail, contact_detail_admin)		