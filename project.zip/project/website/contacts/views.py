from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User


from .models import contact_detail

def home_page(request):
	if request.user.is_authenticated():
		query = contact_detail.objects.all()
		context = {
			"queryset" : query, 
		}
		return render(request, "index.html", context)
	else:
		return redirect('/login/')

def details_page(request, user_id = None):
	if request.user.is_authenticated():
		if user_id is not None:
			query = contact_detail.objects.get(id = user_id)
			# print query
			context = {
				"queryset" : query,
				"command" : 1,
			}
			return render(request, "details.html", context)
	else:
		return redirect('/login/')

def add_detail(request):
	if request.user.is_authenticated():
		context = {
			"command" : 2,
		}
		return render(request, "details.html", context)
	else:
		return redirect('/login/')

def detail_form(request):
	name = request.POST["name"]
	email = request.POST["email"]
	phone_no = request.POST["phone_no"]
	query = contact_detail(name = name, email = email, phone_no = phone_no)
	query.save()
	return redirect('/')

def modify_form(request):
	name = request.POST["modify_name"]
	email = request.POST["modify_email"]
	phone_no = request.POST["modify_phone_no"]
	query = contact_detail.objects.get(name = name)
	query.email = email
	query.phone_no = phone_no
	query.save()
	# update(email = email, phone_no = phone_no)
	return redirect('/')
	

def delete_details(request, user_id = None):
	if request.user.is_authenticated():
		if user_id is not None:
			query = contact_detail.objects.get(id = user_id)
			query.delete()
			return redirect("/")
	else:
		return redirect('/login/')

def login_page(request):
	if request.user.is_authenticated():
		return redirect('/')
	else:
		return render(request, "login.html")

def login_form_data(request):
	username = request.POST["name"]
	password = request.POST["password"]
	user = authenticate(username = username, password = password)
	if user is not None:
		login(request,user)
		return redirect('/')
	else:
		return redirect('/login/')

def signup_page(request):
	if request.user.is_authenticated():
		return redirect('/')
	else:
		return render(request, "signup.html")

def signup_form_data(request):
	username = request.POST["username"]
	email = request.POST["email"]
	password = request.POST["password"]

	if User.objects.filter(email = email).exists() and User.objects.filter(username = username).exists():
		return redirect('/signup/')
	elif User.objects.filter(username=username).exists():
		return redirect('/signup/')
	elif User.objects.filter(email = email).exists():
		return redirect('/signup/')
	
	else:
		user = User.objects.create_user(username, email, password)
		user.save()
		user = authenticate(username = username, password = password)
		login(request,user)
		# print "user is logged in"
		return redirect('/')
